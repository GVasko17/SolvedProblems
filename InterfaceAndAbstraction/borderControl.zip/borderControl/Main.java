package borderControl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        List<String> idList = new ArrayList<>();

        while (!"End".equals(input)) {
            String[] tokens = input.split(" ");
            if (tokens.length == 3) {
                Citizen citizen = new Citizen(tokens[0], Integer.parseInt(tokens[1]), tokens[2]);
                idList.add(tokens[2]);
            } else {
                Robot robot = new Robot(tokens[0], tokens[1]);
                idList.add(tokens[1]);
            }

            input = scanner.nextLine();
        }
        int detainedId = Integer.parseInt(scanner.nextLine());

        for (String id : idList) {
            if (id.endsWith(String.valueOf(detainedId))) {
                System.out.println(id);
            }
        }
    }
}
