package definePerson;

public interface Identifiable {
    String getId();
}
