package birthdayCelebrations;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> birthDatesList = new ArrayList<>();

        String input = scanner.nextLine();

        while (!"End".equals(input)) {
            String[] tokens = input.split(" ");
            if (tokens[0].equals("Citizen")) {
                Citizen citizen = new Citizen(tokens[1], Integer.parseInt(tokens[2]), tokens[3], tokens[4]);
                birthDatesList.add(tokens[4]);
            } else if (tokens[0].equals("Pet")) {
                Pet pet = new Pet(tokens[1], tokens[2]);
                birthDatesList.add(tokens[2]);
            } else {
                Robot robot = new Robot(tokens[1], tokens[2]);
            }

            input = scanner.nextLine();
        }

        int year = Integer.parseInt(scanner.nextLine());

        for (String birthDate : birthDatesList) {
            if (birthDate.endsWith(String.valueOf(year))) {
                System.out.println(birthDate);
            }
        }

        }
    }


