package definePerson;

public interface Birthable {
    String getBirthDate();
}
