package telephony;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<String> numbers = Arrays.stream(scanner.nextLine().split("\\s+"))
                .collect(Collectors.toList());
        List<String> sites = Arrays.stream(scanner.nextLine().split("\\s+"))
                .collect(Collectors.toList());

        Smartphone smartphone = new Smartphone(numbers, sites);

        boolean isOK = false;

        for (int i = 0; i < numbers.size(); i++) {
            String currentNum = numbers.get(i);

            for (int j = 0; j < currentNum.length(); j++) {
                char currentSymbol = currentNum.charAt(j);
                if (!Character.isDigit(currentSymbol)) {
                    System.out.println("Invalid number!");
                    isOK = false;
                    break;
                }
                isOK = true;
            }
            if (isOK) {
                System.out.println(smartphone.call() + " " + currentNum);
            }
        }

        for (int i = 0; i < sites.size(); i++) {
            String currentSite = sites.get(i);

            for (int j = 0; j < currentSite.length(); j++) {
                char currentSymbol = currentSite.charAt(j);
                if (Character.isDigit(currentSymbol)) {
                    System.out.println("Invalid URL!");
                    isOK = false;
                    break;
                }
                isOK = true;
            }

            if (isOK) {
                System.out.println(smartphone.browse() + " " + currentSite + "!");
            }
        }

    }
}
