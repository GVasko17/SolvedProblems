package carShop;

public interface Sellable {
    Double getPrice();

}
