package carShop;

public abstract class CarImpl implements Car{
    public String name;
    public String color;
    public Integer horsePower;
    public String countryProduced;

    public CarImpl(String name, String color, Integer horsePower, String countryProduced) {
        this.name = name;
        this.color = color;
        this.horsePower = horsePower;
        this.countryProduced = countryProduced;
    }

    @Override
    public String getModel() {
        return this.name;
    }

    @Override
    public String getColor() {
        return this.color;
    }

    @Override
    public Integer getHorsePower() {
        return this.horsePower;
    }

    @Override
    public String countryProduced() {
        return this.countryProduced;
    }

    @Override
    public String toString() {
        return String.format(
                "This is %s produced in %s and have %d tires%n",
                name,
                countryProduced,
                TIRES
        );
    }
}
